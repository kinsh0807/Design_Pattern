package com.masai.creational_pattern.bridge;

public class BridgeTester {

	public static void main(String[] args) {
		//Color red = new RedColor();
		Shape triangle = new Triangle(new RedColor());
		triangle.applyColor();

		Shape circle = new Circle(new GreenColor());
		circle.applyColor();
	}

}
