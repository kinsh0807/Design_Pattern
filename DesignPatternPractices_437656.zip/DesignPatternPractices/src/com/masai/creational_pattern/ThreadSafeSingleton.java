package com.masai.creational_pattern;

public class ThreadSafeSingleton {

private static ThreadSafeSingleton instance;
	
	private ThreadSafeSingleton() {}
	
	public static synchronized ThreadSafeSingleton getIntance() {
		if(instance == null)
			instance = new ThreadSafeSingleton(); //instance is lazily initialized when we ask for it
		
		return instance;
	}
}
