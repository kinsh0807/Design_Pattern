package com.masai.creational_pattern.decorator;

public interface Car {

	public void assemble();
}
