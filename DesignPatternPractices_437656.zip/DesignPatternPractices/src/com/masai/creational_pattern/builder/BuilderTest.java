package com.masai.creational_pattern.builder;

public class BuilderTest {

	public static void main(String[] args) {
		
		//Computer computer = new Computer.ComputerBuilder("500GB", "16GB").build();
		
		Computer computer = new Computer.ComputerBuilder("500GB", "16GB").setBluetoothEnabled(true).setGraphicCardEnabled(true).build();
		
		System.out.println(computer);

	}

}
