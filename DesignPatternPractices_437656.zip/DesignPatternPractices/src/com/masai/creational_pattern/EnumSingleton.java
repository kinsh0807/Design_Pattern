package com.masai.creational_pattern;

public enum EnumSingleton {

	INSTANCE;
	
	public void myMethod() {
		System.out.println("Hello How are you..!");
	}
}
