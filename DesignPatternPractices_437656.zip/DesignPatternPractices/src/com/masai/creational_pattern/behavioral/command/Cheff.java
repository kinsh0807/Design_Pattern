package com.masai.creational_pattern.behavioral.command;

public class Cheff {

	public void cookFries() {
		System.out.println("Cheff is cooking fries..!");
	}
	
	public void cookPaste() {
		System.out.println("Cheff is cooking pasta..!");
	}
	
	public void bake() {
		System.out.println("Cheff is baking cake..!");
	}
}
