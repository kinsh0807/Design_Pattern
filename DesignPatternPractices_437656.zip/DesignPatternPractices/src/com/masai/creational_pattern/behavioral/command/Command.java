package com.masai.creational_pattern.behavioral.command;

public interface Command {

	public void execute();
}
