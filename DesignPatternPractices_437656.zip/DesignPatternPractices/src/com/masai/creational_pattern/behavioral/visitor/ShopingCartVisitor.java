package com.masai.creational_pattern.behavioral.visitor;

public interface ShopingCartVisitor {

	//public int visit(Book book);
	
	//public int visit(Fruit fruit);
	
	public int visit(Item item);
}
