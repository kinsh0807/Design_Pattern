package com.masai.creational_pattern.behavioral.visitor;

public class Fruit implements Item{

	private int pricePerKg;
	private int weight;
	private String name;
	
	public Fruit(int pricePerKg, int weight, String name) {
		this.pricePerKg = pricePerKg;
		this.weight = weight;
		this.name = name;
	}
	
	public int getPricePerKg() {
		return this.pricePerKg;
	}
	
	public int getWeight() {
		return this.weight;
	}
	
	public String getName() {
		return this.name;
	}
	@Override
	public int accept(ShopingCartVisitor visitor) {
		return visitor.visit(this);
	}
	

}
