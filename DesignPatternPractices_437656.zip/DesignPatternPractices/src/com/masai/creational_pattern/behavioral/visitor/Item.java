package com.masai.creational_pattern.behavioral.visitor;

public interface Item {

	public int accept(ShopingCartVisitor visitor);
	
}
