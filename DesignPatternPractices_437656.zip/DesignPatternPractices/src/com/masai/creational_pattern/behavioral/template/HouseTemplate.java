package com.masai.creational_pattern.behavioral.template;

public abstract class HouseTemplate {

	public void buildHouse() {
		buildFoundation();
		buildPillars();
		buildWalls();
		buildWindows();
		System.out.println("House construction completed..!");
	}
	
	private void buildWindows() {
		System.out.println("Building glass windows..!");
	}
	
	private void buildFoundation() {
		System.out.println("Building foundation using cement and concrete..!");
	}
	
	public abstract void buildWalls();
	
	public abstract void buildPillars();
}
