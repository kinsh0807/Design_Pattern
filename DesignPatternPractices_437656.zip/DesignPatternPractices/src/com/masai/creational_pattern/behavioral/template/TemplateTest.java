package com.masai.creational_pattern.behavioral.template;

public class TemplateTest {

	public static void main(String[] args) {
		HouseTemplate house = new WoodenHouse();
		house.buildHouse();

		System.out.println("====================");
		house = new GlassHouse();
		house.buildHouse();
	}

}
