package com.masai.creational_pattern.composite;

public interface Shape {

	public void draw(String fillColor);
	
}
