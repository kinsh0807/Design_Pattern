package com.masai.creational_pattern.composite;

public class CompositeTest {

	public static void main(String[] args) {
		
		Shape triangle1 = new Triangle();
		Shape triangle2 = new Triangle();
		Shape circle1 = new Circle();
		Shape circle2 = new Circle();
		
		Drawing drawing = new Drawing();
		drawing.addShape(triangle1);
		drawing.addShape(triangle2);
		drawing.addShape(circle1);
		drawing.addShape(circle2);
		
		drawing.draw("Reddd");
		
		drawing.clearAll();
		
		drawing.addShape(triangle2);
		drawing.addShape(circle1);
		drawing.draw("Blackkkkk");

	}

}
