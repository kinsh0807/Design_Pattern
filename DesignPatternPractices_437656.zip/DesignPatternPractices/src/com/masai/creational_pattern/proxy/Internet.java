package com.masai.creational_pattern.proxy;

public interface Internet {

	public void connect(String url) throws Exception;
	
}
