package com.masai.creational_pattern.proxy;

public class ProxyTest {

	public static void main(String[] args) {
		Internet internet = new ProxyInternet();
		
		try {
			internet.connect("masaischool.com");
			internet.connect("abc.com");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
