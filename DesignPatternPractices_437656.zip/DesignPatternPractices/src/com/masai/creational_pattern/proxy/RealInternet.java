package com.masai.creational_pattern.proxy;

public class RealInternet implements Internet{

	@Override
	public void connect(String url) throws Exception{
		System.out.println("Connected to "+url);
	}
	
}
