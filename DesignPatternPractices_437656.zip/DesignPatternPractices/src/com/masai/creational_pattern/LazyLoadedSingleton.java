package com.masai.creational_pattern;

public class LazyLoadedSingleton {

	private static LazyLoadedSingleton instance;
	
	private LazyLoadedSingleton() {}
	
	public static LazyLoadedSingleton getIntance() {
		if(instance == null)
			instance = new LazyLoadedSingleton(); //instance is lazily initialized when we ask for it
		
		return instance;
	}
	
}
