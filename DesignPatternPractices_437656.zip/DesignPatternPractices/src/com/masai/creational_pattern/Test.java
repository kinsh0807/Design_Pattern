package com.masai.creational_pattern;

public class Test {

	public static void main(String[] args) {
		
		EnumSingleton singleton = EnumSingleton.INSTANCE;
		
		EnumSingleton singleton2 = EnumSingleton.INSTANCE;
		
		System.out.println(singleton.hashCode());
		System.out.println(singleton2.hashCode());
		
		singleton.myMethod();
		
		//AnotherSingleton anotherSingleton = AnotherSingleton.getInstance();
		//AnotherSingleton anotherSingleton2 = AnotherSingleton.getInstance();
		
		//System.out.println(anotherSingleton.hashCode());
		//System.out.println(anotherSingleton2.hashCode());
		
		//LazyLoadedSingleton singleton = LazyLoadedSingleton.getIntance();
		
		//LazyLoadedSingleton singleton2 = LazyLoadedSingleton.getIntance();
		
		//System.out.println(singleton.hashCode());
		//System.out.println(singleton2.hashCode());
		
		/*SimpleSingleton singleton =  SimpleSingleton.getInstance();
		
		System.out.println(singleton.hashCode());
		
		SimpleSingleton singleton2 =  SimpleSingleton.getInstance();

		System.out.println(singleton2.hashCode());*/
	}

}
