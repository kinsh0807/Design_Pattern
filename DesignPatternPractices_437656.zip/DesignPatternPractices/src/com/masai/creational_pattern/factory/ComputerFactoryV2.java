package com.masai.creational_pattern.factory;

public class ComputerFactoryV2 {

	public static Computer getComputer(ComputerAbstractFactory factory) {
		return factory.createComputer();
	}
}
