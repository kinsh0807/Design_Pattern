package com.masai.creational_pattern.factory;

public abstract class Computer {

	public abstract String getRAM();
	public abstract String getHDD();
	public abstract String getCPU();
	
	public String toString() {
		return "RAM="+getRAM()+", HDD="+getHDD()+", CPU="+getCPU();
	}
}
